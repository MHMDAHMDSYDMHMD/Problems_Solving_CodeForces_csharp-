﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text.RegularExpressions;
using System.Text;
using System.Threading.Tasks;

namespace propblemsolving
{
    class A_Palindromes_Replace
    {
        //A. Palindromes Replace
        public void Palindromes_Replace()
        {
            try
            {
                Console.WriteLine("A_Palindromes_Replace \n          Palindromes_Replace");
                Console.WriteLine();
                Console.WriteLine("___________________________________________________________");

                char letter;
                bool test = true;
            start:
                Console.Write("enter the string :");
                string strcheck = Console.ReadLine();
                char[] letterarray = strcheck.ToCharArray();
                int lengthstring = strcheck.Length;
                // strat level check
                if ((strcheck.Length < 100 || strcheck.Length > 0))
                {
                    for (int i = 0; i < strcheck.Length; i++)
                    {
                        if ((strcheck[i] >= 97 && strcheck[i] <= 122) || strcheck[i] == 63) test = true;
                        else { test = false; break; }
                    }

                    // end level check
                    // strat level exec
                    if (test)
                    {
                        for (int x = 0; x <= strcheck.Length / 2; x++)
                        {
                            letter = strcheck[x];
                            if (letterarray[lengthstring - x - 1] == '?')
                            {
                                letterarray[lengthstring - x - 1] = letterarray[x]; // Mirror from the first half
                            }
                            if (letterarray[x] == '?')
                            {
                                letterarray[x] = letterarray[lengthstring - x - 1]; // Mirror from the other half
                            }
                            if (letterarray[x] != letterarray[lengthstring - x - 1])
                            {
                                Console.WriteLine("-1"); // Not a palindrome
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("please letter must be between <a..z and ?>");
                        goto start;
                    }
                }
                else
                {
                    Console.WriteLine("please letter must be it length not more 100");
                    goto start;
                }
                // end level exec


                //print the array 
                for (int o = 0; o < letterarray.Length; o++)
                {
                    Console.Write(letterarray[o]);
                }
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }
        }
    }
    class B_DeletefromtheLeft
    {

        public void Delete_from_the_Left()
        {
            try
            {
                Console.WriteLine("B_DeletefromtheLeft \n          Delete_from_the_Left");
                Console.WriteLine();
                //<<<<<<<<<<<<<< B. Delete from the Left
                Console.WriteLine("___________________________________________________________");

                Console.Write("enter first string : ");
                string str1 = Console.ReadLine().Trim();
                Console.Write("enter second string :");
                string str2 = Console.ReadLine().Trim();
                int commonPrefixLength = 0;
                int minLength = Math.Min(str1.Length, str2.Length);
                // Find the longest common prefix
                for (int i = 0; i < minLength; i++)
                {
                    if (str1[i] == str2[i])
                    {
                        commonPrefixLength++;
                    }
                    else
                    {
                        continue;
                    }
                }

                // Calculate the moves needed to delete non-common characters
                int moves = (str1.Length - commonPrefixLength) + (str2.Length - commonPrefixLength);
                Console.WriteLine(moves);


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }

        }

        public static implicit operator B_DeletefromtheLeft(A_Palindromes_Replace v)
        {
            throw new NotImplementedException();
        }
    }
    class C_Koko_And_The_Transformation
    {

        public void Koko_And_The_Transformation()
        {
            try
            {
                Console.WriteLine("C_Koko_And_The_Transformation \n          Koko_And_The_Transformation");
                Console.WriteLine();
                //<<<<<<<<<<<<<<<<<<<< C. Koko And The Transformation
                Console.WriteLine("___________________________________________________________");

                Console.Write("enter n :");
                int n = Convert.ToInt32(Console.ReadLine());
                Console.Write("enter m :");
                int m = Convert.ToInt32(Console.ReadLine());
                Console.Write("enter array 1 :");
                int[] arr1 = Array.ConvertAll(Console.ReadLine().Split(' '), int.Parse);
                Console.Write("enter array 2 :");
                int[] arr2 = Array.ConvertAll(Console.ReadLine().Split(' '), int.Parse);
                Console.Write("can tranforms ? :");
                Console.WriteLine(Transform(arr1, arr2) ? "Yes" : "No");



            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }

        }


        static bool Transform(int[] a, int[] b)
        {
            int sumA = a.Sum();
            int sumB = b.Sum();

            //            Check if sums are equal
            if (sumA != sumB) return false;

            //  Check if lengths are equal (already transformed)
            if (a.Length == b.Length) return true;

            //        Try splitting or merging elements
            if (a.Length > b.Length)
            {
                return Split(a, b);
            }
            else
            {
                return Merge(a, b);
            }
        }

        static bool Split(int[] a, int[] b)
        {
            for (int i = 0; i < a.Length; i++)
            {
                for (int j = 1; j < a[i]; j++)
                {
                    int[] newA = a.Where(x => x != a[i]).ToArray();
                    newA = newA.Concat(new[] { j, a[i] - j }).ToArray();
                    if (Transform(newA, b)) return true;
                }
            }
            return false;
        }

        static bool Merge(int[] a, int[] b)
        {
            for (int i = 0; i < a.Length; i++)
            {
                for (int j = i + 1; j < a.Length; j++)
                {
                    int[] newA = a.Where(x => x != a[i] && x != a[j]).ToArray();
                    newA = newA.Concat(new[] { a[i] + a[j] }).ToArray();
                    if (Transform(newA, b)) return true;
                }
            }
            return false;
        }

    }
    class D_Hussien_and_Strings
    {
        public void Hussien_and_Strings()
        {
            try
            {
                Console.WriteLine("D_Hussien_and_Strings \n          Hussien_and_Strings");
                Console.WriteLine();
                // <<<<<<<<<<<<<<<<<<<< D_Hussien_and_Strings
                //bool check = true;
                Console.WriteLine("___________________________________________________________");
                Console.Write("enter first string :");
                string text1 = Console.ReadLine();
                Console.Write("enter second string :");
                string text2 = Console.ReadLine();


                Console.WriteLine(MethodCheck(text1, text2) ? "yes" : "no");

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }

        }
        static bool MethodCheck(string text1, string text2)
        {
            if (text1.Length != text2.Length)
            { return false; }
            int dfcnt = 0;
            int dfind1 = -1;
            int dfind2 = -1;
            for (int i = 0; i < text1.Length; i++)
            {
                if (text1[i] != text2[i])
                {
                    dfcnt++;
                    if (dfcnt > 2) return false;
                    dfind1 = dfind1 == -1 ? i : dfind2;
                    dfind2 = i;
                }
            }
            return (dfcnt == 2 && text1[dfind1] == text2[dfind2] && text1[dfind2] == text2[dfind1]);

        }
    }
    class E_Construct_The_Sum
    {
        public void Construct_The_Sum()
        {
            try
            {
                Console.WriteLine("E_Construct_The_Sum \n          Construct_The_Sum");
                Console.WriteLine();
                //  <<<<<<<<<<<<<<<<< E.Construct The Sum
                Console.WriteLine("___________________________________________________________");
                Console.Write("enter the number of line wants :");
                int numt = Convert.ToInt32(Console.ReadLine());
                int ei = 1;
                int numn;
                int nums;
                while (ei <= numt)
                {
                    numbers = new List<int>();
                    Console.Write($"line {ei} : enter the number (n) :");
                    numn = Convert.ToInt32(Console.ReadLine());
                    Console.Write($"line {ei} : enter the number (s) :");
                    nums = Convert.ToInt32(Console.ReadLine());
                    bool found = finddistinct(numn, nums);
                    if (found)
                    {
                        Console.WriteLine(numbers.Count);
                        foreach (int number in numbers)
                        {
                            Console.Write(number);
                        }
                        Console.WriteLine();
                    }
                    else
                    {
                        Console.WriteLine(-1);
                    }
                    ei++;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }

        }
        static List<int> numbers = new List<int>();
        static bool finddistinct(int n, int s, int currentNum = 1)
        {
            if (s == 0)
            {
                return true;
            }

            if (s < 0 || currentNum > n)
            {
                return false;
            }
            for (int i = currentNum; i <= n; i++)
            {
                if (numbers.Contains(i))
                {
                    continue;
                }

                numbers.Add(i);
                if (finddistinct(n, s - i, i + 1))
                {
                    return true;
                }
                numbers.RemoveAt(numbers.Count - 1);
            }

            return false;

            //bool arraytest = true;
            //int[] testerarray = new int[n];
            //int sum = 0;
            //for (int i = 0, d = 1; i < n; i++, d++)
            //{
            //    testerarray[i] = d;
            //}
            //for (int a = 0; a < testerarray.Length; a++)
            //{
            //    sum = 0;
            //    //sum = testerarray[a];
            //    for (int b = testerarray.Length - 1; b > 0; b--)
            //    {

            //        sum = testerarray[b] + testerarray[a];
            //        if (sum == s)
            //        {
            //            Console.Write($"{testerarray[a]},{testerarray[b]} ");
            //            arraytest = false;
            //            break;
            //        }
            //    }
            //}

            //return arraytest;

        }

    }
    class F_Marks
    {
        public void Marks()
        {
            try
            {
                Console.WriteLine("F_Marks \n          Marks");
                Console.WriteLine();
                // <<<<<<<<<<<<<<< F. Marks
                string strsubject = "";
                int testercheck = 0;
                int beststudent = 0;
            start:
                Console.Write("enter the n and s (1 ≤ n, s ≤ 100) 'must write SPACE between numbers' : ");
                int[] n_s = Array.ConvertAll(Console.ReadLine().Split(' '), int.Parse);
                int[,] subjects = new int[n_s[0], n_s[1]];
                if ((n_s[0] > 1) && (n_s[0] <= 100) && (n_s[1] > 1) && (n_s[1] <= 100))
                {
                    for (int countn = 0; countn < n_s[0]; countn++)
                    {
                        Console.Write($"enter the subjects: ");
                        strsubject = Console.ReadLine().Trim();
                        if (strsubject.Length != n_s[1])
                        {
                            Console.WriteLine("please enter the right input");
                            goto start;
                        }
                        else
                        {
                            for (int counts = 0; counts < n_s[1]; counts++)
                            {

                                subjects[countn, counts] = Convert.ToInt32(strsubject[counts].ToString());
                                // this step is no good (no good = غير مفيد)
                                //if(subjects[counts, countn] > 9)
                                //{
                                //    Console.WriteLine("please enter the right input\n error : << must be subject smallar than or equal 9 >> ");
                                //    goto start;
                                //}
                            }
                        }
                    }
                }
                else
                {
                    Console.WriteLine("please enter the right input");
                    goto start;
                }
                testercheck = subjects[0, 0];
                for (int countn = 0; countn < n_s[1]; countn++)
                {
                    for (int counts = 0; counts < n_s[0]; counts++)
                    {

                        if (testercheck < subjects[counts, countn])
                        {
                            testercheck = subjects[counts, countn];
                            beststudent = counts;
                        }
                    }
                }
                Console.WriteLine(beststudent + 1);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }

        }


    }
    class I_Coins
    {
        public void Coins()
        {
            try
            {
                Console.WriteLine("ICoins \n          Coins");
                Console.WriteLine();
            start:
                int num0 = 0;
                int num1 = 0;
                int num2 = 0;
                //string greater = "";
                char[] litterarray = new char[3];
                string[] graeterarray = new string[3];
                for (int i = 0; i < 3; i++)
                {
                    Console.Write($"{1 + i}- enter like (letter<letter or letter>letter) please : ");
                    graeterarray[i] = Console.ReadLine();
                    if (graeterarray[i].Length != 3 || (graeterarray[i][1] != '>' && graeterarray[i][1] != '<'))
                    {
                        goto start;
                    }
                    else
                    {
                        for (int x = 0; x < graeterarray[i].Length; x++)
                        {
                            if (graeterarray[i][x] != '>' && graeterarray[i][x] != '<')
                            {
                                if (!litterarray.Contains(graeterarray[i][x]))
                                {
                                    litterarray[i] = graeterarray[i][x];
                                }
                            }
                        }
                    }
                }

                foreach (var item in graeterarray)
                {
                    for (int i = 0; i < item.Length; i++)
                    {
                        if (item[i] == '>')
                        {
                            if (litterarray[0] == item[1 - i])
                            {
                                num0++;
                            }
                            if (litterarray[1] == item[1 - i])
                            {
                                num1++;
                            }
                            if (litterarray[2] == item[1 - i])
                            {
                                num2++;
                            }
                        }
                        if (item[i] == '<')
                        {
                            if (litterarray[0] == item[1 + i])
                            {
                                num0++;
                            }
                            if (litterarray[1] == item[1 + i])
                            {
                                num1++;
                            }
                            if (litterarray[2] == item[1 + i])
                            {
                                num2++;
                            }
                        }
                    }
                }
                Console.WriteLine(litterarray[num0].ToString() + litterarray[num1].ToString() + litterarray[num2].ToString());
                //if (num0 >= num1|| num0 >= num1)
                //{
                //    Console.Write(litterarray[0]);
                //}
                //if (num1 >= num0 || num1 >= num2)
                //{
                //    Console.Write(litterarray[1]);
                //}
                //if (num0 >= num1 || num0 >= num1)
                //{
                //    Console.Write(litterarray[2]);
                //}
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }
        }
    }
    class J_Help_Vasilisa_the_Wise_2
    {
        public void Help_Vasilisa_the_Wise_2()
        {
            try
            {
                Console.WriteLine("J_Help_Vasilisa_the_Wise_2 \n          Help_Vasilisa_the_Wise_2");
                Console.WriteLine();
            start:
                Console.Write("enter r1&r2 :");
                uint[] requireds = Array.ConvertAll(Console.ReadLine().Split(' '), uint.Parse);
                uint sum_required_1 = requireds[0];
                uint sum_required_2 = requireds[1];
                Console.Write("enter c1&c2 :");
                requireds = Array.ConvertAll(Console.ReadLine().Split(' '), uint.Parse);
                uint sum_columns_1 = requireds[0];
                uint sum_columns_2 = requireds[1];
                Console.Write("enter d1&d2 :");
                requireds = Array.ConvertAll(Console.ReadLine().Split(' '), uint.Parse);
                uint sum_side_diagonals_1 = requireds[0];
                uint sum_side_diagonals_2 = requireds[1];
                if (!((sum_required_1 + sum_required_2 + sum_columns_1 + sum_columns_2 + sum_side_diagonals_1 + sum_side_diagonals_2) <= 120))
                {
                    goto start;
                }
                uint i1 = 0, i2 = 0, i3, i4 = 0;
                bool test = false;
                for (i1 = 1; i1 < sum_required_1; i1++)
                    for (i2 = sum_required_1; i2 > 0; i2--)
                        if ((i1 + i2) == sum_required_1)
                            for (i3 = 1; i3 < sum_required_2; i3++)
                                for (i4 = sum_required_2; i4 > 0; i4--)
                                    if ((i3 + i4) == sum_required_2)
                                        if ((i3 + i2) == sum_side_diagonals_2)
                                            if ((i1 + i4) == sum_side_diagonals_1)
                                                if ((i1 + i3) == sum_columns_1)
                                                    if ((i2 + i4) == sum_columns_2)
                                                    {
                                                        if (i1 == 5 || i2 == 5 || i3 == 5 || i4 == 5)
                                                            continue;
                                                        Console.WriteLine($"{i1} {i2}\n{i3} {i4}");
                                                        test = true;
                                                        break;
                                                    }
                if (!test) Console.WriteLine("-1");
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }
        }
    }
    class M_Postcard
    {
        public void Postcard()
        {
            try
            {
                Console.WriteLine("M_Postcard \n___________Postcard");
                Console.WriteLine("# => for repeat prevois letter\n* => repeat next letter\n? => delete prevois letter\n$ => delete next letter");
                Console.WriteLine();
            start:
                Console.Write("enter string  :");
                string strfromuser = Console.ReadLine();
                Console.Write("enter length of dtring  :");
                int lengthofk = Convert.ToInt32(Console.ReadLine());
                bool check = false, checkmarks = false;
                int questionmark = 0, starmark = 0, hashmark = 0, dolormark = 0;
                char[] arr = strfromuser.ToCharArray();
                for (int i = 0; i < strfromuser.Length; i++)
                {
                    if ((strfromuser[i] != '?' && strfromuser[i] != '*' && strfromuser[i] != '#' && strfromuser[i] != '$') && strfromuser.Length == lengthofk) check = true;
                    if (strfromuser[i] == '?') questionmark++;
                    if (strfromuser[i] == '*') starmark++;
                    if (strfromuser[i] == '#') hashmark++;
                    if (strfromuser[i] == '$') dolormark++;
                    if (!(strfromuser[i] >= 0x41 && strfromuser[i] <= 0x7A) && (strfromuser[i] != '?' && strfromuser[i] != '*' && strfromuser[i] != '$' && strfromuser[i] != '#')) { checkmarks = true; break; }
                }
                if (check) Console.WriteLine(strfromuser);
                if (checkmarks) goto start;
                check = true;
                if ((questionmark == 1 && starmark == 1 && dolormark == 1 && hashmark == 1) && lengthofk == (strfromuser.Length - (questionmark + starmark + hashmark + dolormark)))
                {
                    foreach (var item in arr)
                    {
                        if (item != '?' && item != '*' && item != '#' && item != '$')
                            Console.Write(item);
                    }

                    Console.WriteLine();
                }
                if (lengthofk < (strfromuser.Length - (questionmark + starmark + hashmark + dolormark)))
                {
                    Console.WriteLine("Impossible");
                }
                else
                {
                    //foreach (var item in arr)
                    //{
                    //    if (item != '?' && item != '*'&& item != '#' && item != '$')
                    //        Console.Write(item);
                    //}
                }
                char[] finalarr = new char[lengthofk + lengthofk];
                finalarr[0] = arr[0];
                int n = 0;
                foreach (var item in arr)
                {
                    if (Array.IndexOf(arr, item) != 0)
                    {
                        n++;
                        if (item == '?') continue;
                        if (arr[Array.IndexOf(arr, item) + 1] == '?') continue;
                        if (item == '$') continue;
                        if (arr[Array.IndexOf(arr, item) - 1] == '$') continue;
                        if (item == '*') { finalarr[n] = arr[Array.IndexOf(arr, item) + 1]; continue; }
                        if (item == '#') { finalarr[n] = arr[(Array.IndexOf(arr, item) - 1)]; continue; }
                        finalarr[n] = item;
                        Console.WriteLine(finalarr[n]);
                    }

                    Console.Write(item);

                }
                Console.WriteLine("final");
                foreach (var item in finalarr)
                {
                    if (item >= 0x41 && item <= 0x7A)
                        Console.WriteLine(item);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }
        }
    }
    class N_Katryoshka

    {
        public void Katryoshka()
        {
            try
            {
                Console.WriteLine("N_Katryoshka \n___________ Katryoshka");
            start:
                Console.Write("enter the length of eyes & body & mouth :");
                int[] nmk = Array.ConvertAll(Console.ReadLine().Trim().Split(' '), int.Parse);
                Random r = new Random();
                int randomz = r.Next(0, 9);
                foreach (var item in nmk)
                {
                    if (!(nmk[0] <= 10e+18) || nmk.Length != 3)
                    {
                        goto start;
                    }
                }
                int nEYES = nmk[0];
                int mMOUTHZ = nmk[1];
                int kBODY = nmk[2];
                if (kBODY == 0 || nEYES == 0) { Console.WriteLine(0); return; }
                if (mMOUTHZ == 0) { Console.WriteLine(nEYES / 2); return; }
                if (nmk[0] != nmk.Min()) { Console.WriteLine(nmk[0]); }
                if (randomz % 2 == 0) Console.WriteLine(((nEYES - mMOUTHZ) / 2) + mMOUTHZ);
                if (randomz % 2 != 0) Console.WriteLine((nEYES - mMOUTHZ) + mMOUTHZ);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }
        }
    }
    class O_Help_Koko
    {
        public void Help_Koko()
        {
            try
            {
                Console.WriteLine("O_Help_Koko \n___________ Help_Koko");
            start:
                Console.Write("enter N and X  : ");
                int[] NandX = Array.ConvertAll(Console.ReadLine().Trim().Split(' '), int.Parse);
                Console.Write("enter N space-separated  : ");
                int[] Nspace_separated = Array.ConvertAll(Console.ReadLine().Trim().Split(' '), int.Parse);
                Console.Write("enter operations (1 or 2) : ");
                int[] operations = Array.ConvertAll(Console.ReadLine().Trim().Split(' '), int.Parse);
                for (int i = 0; i < NandX[0]; i++)
                {
                    if (NandX.Length != 2
    || Nspace_separated.Length != NandX[0]
    || operations.Length != NandX[0]
    || NandX[0] > 10e5
    || NandX[1] > 1000
    || Nspace_separated[i] > 10e+6)
                    {
                        Console.WriteLine("something is wrong");
                        goto start;
                    }
                }

                for (int i = 0; i < operations.Length; i++)
                {
                    char[] digits;
                    var item = operations[i];
                    var it = Nspace_separated[i];
                    int resault = 0;
                    if (item != 2 && item != 1)
                    { Console.WriteLine("somethig is wrong"); goto start; }
                    else
                    {
                        bool isprime = true;
                        if (item == 1)
                        {
                            for (int x = 2; x <= (int)Math.Sqrt(it); x++)
                            {
                                if (it % x != 0) isprime = true;
                                else isprime = false; break;
                            }
                            if (isprime)
                            {
                                resault = (int)((it * Math.Pow(5, NandX[1])) * Math.Pow(3, NandX[1]));
                                digits = resault.ToString().ToCharArray();
                                Console.Write(digits[digits.Length - 1] + ' ');
                            }
                            else Console.Write("-1");
                        }

                        if (item == 2)
                        {
                            resault = (int)((it * Math.Pow(2, NandX[1])) * Math.Pow(5, NandX[1]));
                            digits = resault.ToString().ToCharArray();
                            Console.Write(digits[digits.Length - 1] + ' ');
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }
        }
    }
    class P_No_Time_for_Dragons
    {
        public void No_Time_for_Dragons()
        {
            try
            {
                Console.WriteLine("P_No_Time_for_Dragons \n___________ No_Time_for_Dragons");
            start:
                Console.Write("enter number of dragons : ");
                double numberofdragons = Convert.ToInt32(Console.ReadLine().Trim());
                double[,] aandb = new double[(int)numberofdragons, 2];
                double convertor = 0;
                for (int i = 0; i < numberofdragons; i++)
                {
                    char ch = Convert.ToChar(0x61);
                    for (int x = 0; x < aandb.GetLength(1); x++)
                    {
                        Console.Write($"enter {Convert.ToChar(ch+x)}{i+1} : ");
                        aandb[i, x] = Convert.ToDouble(Console.ReadLine());
                    }
                }
                if (numberofdragons > 2.10e+5 && numberofdragons < 0)
                {
                    Console.WriteLine("something is wrong ! "); goto start;
                }
                else
                {
                    for (int i = 0; i < aandb.GetLength(0); i++)
                        for (int x = 0; x < aandb.GetLength(1); x++) if (aandb[i, x] > 10e+9|| numberofdragons < 0) { Console.WriteLine("something is wrong ! "); goto start; }
                }
                for (int i = 0; i < aandb.GetLength(0); i++) convertor += aandb[i, 0] - aandb[i, 1];
                Console.WriteLine($"the resault equal : {convertor+(aandb[aandb.GetLength(0)-1,aandb.GetLength(1)-1])}");
            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }
        }
    }
    class Q_Bulbs
    {
        public void Bulbs()
        {
            try
            {
                Console.WriteLine("Q_Bulbs \n___________ Bulbs");
            start:
                Console.Write("enter number of bulbs : ");
                int thenumberofbulbs = Convert.ToInt32(Console.ReadLine().Trim());
                Console.Write("enter bulb's number ( 1 to number of bulbs ): ");
                int[] bulbnumber = new int[thenumberofbulbs];
                bulbnumber = Array.ConvertAll(Console.ReadLine().Split(' '), int.Parse);
                Console.Write(" enter number of moment : ");
                int numberofmoment = Convert.ToInt32(Console.ReadLine());
                foreach (var item in bulbnumber)
                {
                    if (item > thenumberofbulbs) { Console.WriteLine("must be  bulb's number < number of bulbs "); goto start; }
                    if (numberofmoment == item) Console.WriteLine($"all is on at moment : {Array.IndexOf(bulbnumber, item)+1}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }
        }
    }
    class R_Cut_Ribbon
    { 
        public void Cut_Ribbon()
        {
            try
            {
                Console.WriteLine("R_Cut_Ribbon \n___________ Cut_Ribbon");
            start:
                int lenghtofribbon, anumbered, bminimum, cmaximum, res = 0;
                Console.Write("enter lenght of ribbon & a(numbered) & b(minimum) & c(maximum) : ");
                int[] bulbnumber = new int[4];
                bulbnumber = Array.ConvertAll(Console.ReadLine().Split(' '), int.Parse);
                for (int i = 0; i < 4; i++)
                    if (!(bulbnumber[i] >= 0 && bulbnumber[i] <= 4000))
                    { Console.WriteLine("the numbers is no correct."); goto start; }
                lenghtofribbon = bulbnumber[0];
                anumbered = bulbnumber[1];
                bminimum = bulbnumber[2];
                cmaximum = bulbnumber[3];
                if (bminimum > lenghtofribbon || cmaximum >= lenghtofribbon || lenghtofribbon == 1 || lenghtofribbon == 0 || (cmaximum == bminimum && anumbered != 1) || cmaximum < bminimum||!(cmaximum>1)) { Console.WriteLine("impossioble"); return; }
                if (anumbered == lenghtofribbon) { Console.WriteLine(lenghtofribbon); return; }
                bool test = true;int count = 0;
               for (int i = (bminimum==0)?bminimum+1:bminimum; i <= cmaximum; i++)
                    {
                    res = lenghtofribbon / i;
                            if (res == anumbered) { Console.WriteLine($"number of piece : {res} , length of once piece : {i}");test = false; return; }
                     }
                if (test) Console.WriteLine("impossible !");
            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }
        }
    }
    class S_DZY_Loves_Chessboard
    {
        public void DZY_Loves_Chessboard()
        {
            try
            {
                Console.WriteLine("S_DZY_Loves_Chessboard \n___________ DZY_Loves_Chessboard");
            start:
                Console.Write("enter n and m :");
                int[] n_and_m = Array.ConvertAll(Console.ReadLine().Split(' '), int.Parse);
                if (n_and_m.Length != 2 && n_and_m[0] != n_and_m[1]) 
                { Console.WriteLine("length of prvious line is no correct ! "); goto start; }
                int n = n_and_m[0];
                int m = n_and_m[0];
                string[] characters = new string[n];
                string newcharacters = "";
                for (int i = 0; i < n; i++)
                {
                    Console.Write("enter characters (. or -) :");
                    characters[i] = Console.ReadLine();
                }
                for (int x = 0; x < characters.Length; x++)
                { var item = characters[x];
                    for (int i = 0; i < item.Length; i++)
                    {
                        if (i != 0)
                        {
                            if (item[i] == '.' && item[i - 1] == '.')
                            {
                                if (newcharacters[i - 1] == 'B')
                                {
                                    newcharacters += 'W';
                                    Console.Write("W");
                                    continue;
                                }
                                else
                                {
                                    newcharacters += 'B';
                                    Console.Write("B");
                                    continue;
                                }

                            }
                            else
                            {
                                if (item[i] == '.') { newcharacters += 'B'; Console.Write("B"); continue; }
                                if (item[i] == '-') { newcharacters += '-'; Console.Write("-"); continue; }
                            }
                        }
                        else
                        {
                            if (item[i] == '.') { newcharacters += 'B'; Console.Write("B"); continue; }
                            if (item[i] == '-') { newcharacters += '-'; Console.Write("-"); continue; }
                        }
                    }
                    newcharacters += "\n";
                    Console.WriteLine();
                }
                //foreach (var item in newcharacters)
                //{
                //    Console.WriteLine(item);
                //}
            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }
        }
    }
    class T_Easter_Eggs
    {
        public void Easter_Eggs()
        {
            try
            {
                Console.WriteLine("T_Easter_Eggs \n___________ Easter_Eggs");
                string[] colors = "red,orange,yellow,green,blue,indigo,violet".Split(',');
                string[] letterOFcolors = "r,o,y,g,b,i,v".Split(',');
                Console.Write("enter the nuber of color you want it : ");
                int numofcolor = Convert.ToInt32(Console.ReadLine());
                Console.Write("Letter Of Colors : ");
                for (int i = 0; i < numofcolor; i++)
                {
                    if (i <= letterOFcolors.Length - 1)
                    {
                        Console.Write(letterOFcolors[i]);
                        if (i != numofcolor - 1)
                            Console.Write(" , ");
                    }
                    if (i > letterOFcolors.Length - 1)
                    {
                        Console.Write(letterOFcolors[i - letterOFcolors.Length]);
                        if (i != numofcolor - 1)
                            Console.Write(" , ");
                    }
                }
                Console.WriteLine();
                Console.Write("Colors : ");
                for (int i = 0; i < numofcolor; i++)
                {
                    if (i <= letterOFcolors.Length - 1)
                    {
                        Console.Write(colors[i]);
                        if (i != numofcolor - 1)
                            Console.Write(" , ");
                    }
                    if (i > letterOFcolors.Length - 1)
                    {
                        Console.Write(colors[i - letterOFcolors.Length]);
                        if (i != numofcolor - 1)
                            Console.Write(" , ");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }
        }
    }
    class U_From_S_To_T

    {
        public void From_S_To_T()
        {
            try
            {
                Console.WriteLine("U_From_S_To_T \n___________ From_S_To_T");
            start:
                Console.Write("enter nuber of query : "); int q = Convert.ToInt32(Console.ReadLine());
                string[] Ss = new string[q];
                string[] Ts = new string[q];
                string[] Ps = new string[q];
               // string testitems = "";
                string[] testarrays = { };
                for (int i = 0; i < q; i++)
                {
                    Console.Write($"Ss{i + 1}:"); Ss[i] = Console.ReadLine();
                    Console.Write($"Ts{i + 1}:"); Ts[i] = Console.ReadLine();
                    Console.Write($"Ps{i + 1}:"); Ps[i] = Console.ReadLine();
                    if (Ts.Length < Ps.Length || Ts.Length < Ss.Length || Ss[i].Length > 100 || Ts[i].Length > 100 || Ps[i].Length > 100 || q > 100) { Console.WriteLine("numbers or length of ts array or string length is wrong !"); goto start; }
                }
                int testss = 0;
                int testps = 0;
                for (int i = 0; i < Ts.Length; i++)
                {
                    foreach (var item in Ps[i])
                        for (int x = 0; x < Ts[i].Length; x++)
                            if (item == Ts[i][x])
                                testps++;
                    foreach (var item in Ss[i])
                        for (int n = 0; n < Ts[i].Length; n++)
                            if (item == Ts[i][n])
                                testss++;
                    // Console.WriteLine((Ts[i].Contains(Ss[i]) && Ts[i].Contains(Ps[i]))? "by Contains: yes": "By Contains : no"); // anther ways
                    if (testps == Ps[i].Length && testss == Ss[i].Length) Console.WriteLine("yEs");
                    else Console.WriteLine("nOo");
                    testss = testps = 0;

                }

            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }
        }
    }
    class V_New_Password
    {
        public void New_Password()
        {
            try
            {
                Console.WriteLine("V_New_Password \n___________ New_Password");
            start:
                Console.Write("enter the length of new password : ");
                int lenofnewpassword = Convert.ToInt32(Console.ReadLine());
                Console.Write("enter the number of distinct symbols : ");
                int numofdistinctsymbols = Convert.ToInt32(Console.ReadLine());
                if (!(2 <= lenofnewpassword && lenofnewpassword <= 100 && 2 <= numofdistinctsymbols&&numofdistinctsymbols <= lenofnewpassword))
                {
                    Console.WriteLine("length & numbers is not correct !");
                    goto start;
                }
                string s = "";
                char ch;
                for (int i = 0; i < lenofnewpassword; i++)
                {
                    ch = (char)MethodRandom();
                    if (i != 0)
                    {
                        if (numofdistinctsymbols == lenofnewpassword)
                        {
                            if (s.Contains(ch))
                            {
                                i = i - 1;
                                continue;
                            }
                            else
                            {
                                s += ch;
                            }
                        }
                        else if (!((i + 1) == (numofdistinctsymbols)))
                        {
                            if (s.Contains(ch))
                            {
                                i = i - 1;
                                continue;
                            }
                            else
                            {
                                s += ch;
                            }
                        }
                        else
                        {
                            s += ch;
                        }
                    }
                    else
                    {
                        s += ch;
                    }
                }
                Console.WriteLine(s);

            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }
        }
        public static int MethodRandom()
        {
            Random r = new Random();
            int character;
            character= r.Next(0x61, 0x7A);
            return character;
        }
    }
    class W_Hussien_and_Arrays_2
    {
        public void Hussien_and_Arrays_2()
        {
            try
            {
                Console.WriteLine("W_Hussien_and_Arrays_2 \n___________ Hussien_and_Arrays_2");
                Console.Write("integerN : ");
                int nint = Convert.ToInt32(Console.ReadLine());
                Console.Write("Arrqay 1 contains N integers : ");
                int[] ArrayOfNintegers1 = { };
                ArrayOfNintegers1 = Array.ConvertAll(Console.ReadLine().Split(' '), int.Parse);
                Console.Write("Arrqay 2 contains N integers : ");
                int[] ArrayOfNintegers2 = { };
                ArrayOfNintegers2 = Array.ConvertAll(Console.ReadLine().Split(' '), int.Parse);
                int[] allarray = new int[nint];
                int numMax = (ArrayOfNintegers1.Length > ArrayOfNintegers2.Length) ? ArrayOfNintegers2.Length : ArrayOfNintegers1.Length;
                int old;
                for (int i = 0; i < numMax; i++)
                {
                    if (ArrayOfNintegers1[i] <= ArrayOfNintegers2[i])
                        allarray[i] = ArrayOfNintegers2[i] - ArrayOfNintegers1[i];
                    else
                    {
                        old = ArrayOfNintegers2[i];
                        ArrayOfNintegers2[i] = ArrayOfNintegers1[i];
                        ArrayOfNintegers1[i] = old;
                        allarray[i] = ArrayOfNintegers2[i] - ArrayOfNintegers1[i];
                    }
                }
                Console.WriteLine(allarray.Max());

            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }
        }
    }
    class X_Strange_Addition
    {
        public void Strange_Addition()
        {
            try
            {
                Console.WriteLine("X_Strange_Addition \n___________ Strange_Addition");
                start:
                Console.Write("integerK : ");
                int Kinteger = Convert.ToInt32(Console.ReadLine());
                Console.Write("enter D_Array contains K length : ");
                int[] DArray = Array.ConvertAll(Console.ReadLine().Split(' '), int.Parse);
                if (Kinteger!=DArray.Length)
                {
                    Console.WriteLine("index of array is wrong !");
                    goto start;
                }
                int[] ARRofTrue = new int[Kinteger];
                int m = 0;
                for (int i=0, n = 1; i < DArray.Length; i+=2,n+= 2)
                {

                    if (DArray[i].ToString().Contains("0") || DArray[n].ToString().Contains("0"))
                    {
                        ARRofTrue[m] = DArray[i];
                        ARRofTrue[m + 1] = DArray[n];
                        m = m+2;
                    }
                }
                Console.WriteLine(m);
                foreach (var item in ARRofTrue)
                {
                    if(item!=0)
                    Console.Write(item+" ");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }
        }
    }
    class Y_Spiral
    {
        public void Spiral()
        {
            try
            {
                Console.WriteLine("Y_Spiral \n___________ Spiral");
            start:
                Console.Write("enter the columns of metrix :");
                int n = Convert.ToInt32(Console.ReadLine());
                Console.Write("enter the rows of metrix :");
                int m = Convert.ToInt32(Console.ReadLine());
                if (!(n>0||n<1000||m>0||m<1000))
                {
                    Console.WriteLine("numbers is wrong!!!");
                    goto start;
                }
                Console.Write("enter numbers :");
                int[] NUMsOfSpiral = Array.ConvertAll(Console.ReadLine().Split(' '), int.Parse);
              NUMsOfSpiral=NUMsOfSpiral.OrderBy((x)=>x).ToArray();
                foreach (var item in NUMsOfSpiral)
                {
                    Console.Write(item);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine(ex.Message.ToString());
                Console.WriteLine("please do right every thing to succes run (^_^) !");
                Console.ReadKey();
                //throw ex;
            }
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            #region create objects
            // << create objects >>
            //A_Palindromes_Replace a = new A_Palindromes_Replace();
            //B_DeletefromtheLeft b = new B_DeletefromtheLeft();
            //C_Koko_And_The_Transformation c = new C_Koko_And_The_Transformation();
            //D_Hussien_and_Strings d = new D_Hussien_and_Strings();
            //E_Construct_The_Sum e = new E_Construct_The_Sum();
            //F_Marks f = new F_Marks();
            //I_Coins i = new I_Coins();
            //J_Help_Vasilisa_the_Wise_2 j = new J_Help_Vasilisa_the_Wise_2();
            //M_Postcard m = new M_Postcard();
            //N_Katryoshka n = new N_Katryoshka();
            //O_Help_Koko o = new O_Help_Koko();
            //P_No_Time_for_Dragons p = new P_No_Time_for_Dragons();
            //Q_Bulbs q = new Q_Bulbs();
            //R_Cut_Ribbon r = new R_Cut_Ribbon();
            //S_DZY_Loves_Chessboard s = new S_DZY_Loves_Chessboard();
            //T_Easter_Eggs t = new T_Easter_Eggs();
            //U_From_S_To_T u = new U_From_S_To_T();
            //V_New_Password v= new V_New_Password(); //new V_New_Password().New_Password(); 
            //W_Hussien_and_Arrays_2 w = new W_Hussien_and_Arrays_2();
            //X_Strange_Addition x = new X_Strange_Addition();
            Y_Spiral y = new Y_Spiral();
            #endregion
            #region objects
            // << use objets >>
            //a.Palindromes_Replace();
            //b.Delete_from_the_Left();
            //c.Koko_And_The_Transformation();
            //d.Hussien_and_Strings();
            //e.Construct_The_Sum();
            //f.Marks();
            //g.Smallest_Product();
            //i.Coins();
            //j.Help_Vasilisa_the_Wise_2();
            //m.Postcard();
            //n.Katryoshka();
            //o.Help_Koko();
            //p.No_Time_for_Dragons();
            //q.Bulbs();
            //r.Cut_Ribbon();
            //s.DZY_Loves_Chessboard();
            //t.Easter_Eggs();
            //u.From_S_To_T();
            //v.New_Password();
            //w.Hussien_and_Arrays_2();
            //x.Strange_Addition();
            y.Spiral();
            #endregion
            #region stop whole run
            // stop whole run
            Console.WriteLine();
            Console.WriteLine("enter any button....");
            Console.ReadKey();
            #endregion
            
        }
    }
}
